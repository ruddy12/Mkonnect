#!/usr/bin/python

# Load API Class
from uxtsms import UXTsms

# Setup API credentials	
API_KEY = "Your API Key" # Check under Settings->API key in Tumasms

# API Call to Send Message(s)
# Request	
uxtsms = UXTsms(API_KEY) # Instantiate API library
uxtsms.queue_sms("+254723XXXXXX", "Message 1", "Sender_ID", "") # Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")Replace 0723XXXXXX with recipient and "Message 1." with your message
uxtsms.queue_sms("+254733XXXXXX", "Message 2", "Sender_ID", "") # Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")
uxtsms.send_sms() # Initiate API call to send messages
# Response
print uxtsms.status # View status either (SUCCESS or FAIL)
print uxtsms.message # Returns SMS available (Credits balance)
print uxtsms.description # Returns a status message
print uxtsms.response_xml # Returns full xml response
print uxtsms.response_dict # Returns xml response as a dictionary
print uxtsms.response_json # Returns full json response

# API Call to Check for Available SMS
# Request	
uxtsms = UXTsms(API_KEY) # Instantiate API library
uxtsms.get_balance() # Initiate API call to check available messages
# Response
print uxtsms.status # View status either (SUCCESS or FAIL)
print uxtsms.message # Returns SMS available (Credits balance)
print uxtsms.description # Returns a status message
print uxtsms.response_xml # Returns full xml response
print uxtsms.response_dict # Returns xml response as a dictionary
print uxtsms.response_json # Returns full json response