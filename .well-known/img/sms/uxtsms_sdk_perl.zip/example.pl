#!/usr/bin/perl
use UXTsms;

#API Call to Send Message(s)
#
#Request	
my $uxtsms = new UXTsms;
$uxtsms->{api_key} = ''; #Check under Manage Settings->Manage API in UXTsms 
$uxtsms->queue_sms("+254723XXXXXX", "Message 1.", "Sender_ID", ""); # Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")
$uxtsms->queue_sms("+254733XXXXXX", "Message 2.", "Sender_ID", ""); # Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")
$uxtsms->send_sms();# Initiate API call to send messages

# Response	
print $uxtsms->{status} . "\n"; # View status either (SUCCESS or FAIL)
print $uxtsms->{message} . "\n"; # Returns SMS available (Credits balance)
print $uxtsms->{description} . "\n"; # Returns a status message
print $uxtsms->{response_xml} . "\n"; # Returns full xml response
print $uxtsms->{response_json} . "\n"; # Returns full json response


# API Call to Check for Available SMS
#
# Request
$uxtsms = new UXTsms();
$uxtsms->{api_key} = 'Your API Key'; # Check under Manage Settings->Manage API in UXTsms 
$uxtsms->get_balance(); # Initiate API call to check available messages

# Response
print $uxtsms->{status} . "\n"; # View status either (SUCCESS or FAIL)
print $uxtsms->{message} . "\n"; # Returns SMS available (Credits balance)
print $uxtsms->{description} . "\n"; # Returns a status message
print $uxtsms->{response_xml} . "\n"; # Returns full xml response
print $uxtsms->{response_json} . "\n"; # Returns full json response