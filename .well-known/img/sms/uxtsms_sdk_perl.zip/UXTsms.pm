#!/usr/bin/perl
use strict;
use warnings;
use URI::Escape;
use WWW::Curl::Easy;
use XML::Hash;

package UXTsms;

sub new
{
  my $type = shift;
  my $class = ref($type) || $type;
  my $self  = {};
  
  #api_call
  $self->{api_url} = undef;
  $self->{api_parameters} = undef;
  
  #api_parameters
  $self->{api_key} = undef;
  $self->{sms_messages} = undef;
  
  #response
  $self->{status} = undef;
  $self->{message} = undef;
  $self->{description} = undef;
  $self->{response_xml} = undef;
  $self->{response_json} = undef;
  $self->{message_separator} = undef;
  
  bless ( $self, $class );
  return $self;
}
sub queue_sms
{
	my ( $self, $recipient, $message, $sender = "", $scheduled_date = "") = @_;
	$self->{sms_messages} = "<sms><recipient>" . $recipient . "</recipient><message>" . $message . "</message><sender>" . $sender . "</sender><scheduled_date>" . $scheduled_date . "</scheduled_date></sms>";
	return $self->{sms_messages};
}
sub send_sms
{
	my $self = shift;
	$self->{api_url} = "send_sms";
	$self->{api_parameters} = '&messages=' . URI::Escape::uri_escape("<request>" . $self->{sms_messages} . "</request>");	
	return $self->execute;
}
sub get_balance
{
	my $self = shift;
	$self->{api_url} = "get_balance";
	$self->{api_parameters} = "";
	return $self->execute;
}
sub execute
{
	my $self = shift;
	my $results ="";
	$self->{api_url} = "http://tumasms.co.ke/ts/api/". $self->{api_url};
	$self->{api_parameters} = 'api_key=' . URI::Escape::uri_escape($self->{api_key}) . $self->{api_parameters};
	
	#execute post
	my $curl = WWW::Curl::Easy->new;
	$curl->setopt( WWW::Curl::Easy::CURLOPT_URL, $self->{api_url} );
	$curl->setopt( WWW::Curl::Easy::CURLOPT_HEADER, 0);
	$curl->setopt( WWW::Curl::Easy::CURLOPT_POST, 1);
	$curl->setopt( WWW::Curl::Easy::CURLOPT_POSTFIELDS, $self->{api_parameters} ); 
	$curl->setopt( WWW::Curl::Easy::CURLOPT_TIMEOUT, 180 );
	$curl->setopt( WWW::Curl::Easy::CURLOPT_SSL_VERIFYPEER, 0 );
	$curl->setopt( WWW::Curl::Easy::CURLOPT_SSL_VERIFYHOST,  2 );
	$curl->setopt( WWW::Curl::Easy::CURLOPT_WRITEDATA, \$results );
	my $retcode = $curl->perform;
	
	unless ( $retcode == 0 ) { die("The request could not be completed") };
	#process xml results
	$results =~ s#^\s+##g;
	$results =~ s#\s+$##g;
	
	$self->{response_xml} = $results;
	my $xml_converter = XML::Hash->new();
	my %response_hash = %{ $xml_converter->fromXMLStringtoHash( $self->{response_xml} ) };
  
	$self->{status} = $response_hash{response}->{status}->{type}->{text};
	$self->{message} = $response_hash{response}->{content}->{messages}->{message}->{text};
	$self->{description} = $response_hash{response}->{content}->{description}->{text};
	
	if ( ref($self->{message}) eq "ARRAY" ) {
		$self->{message} = join( $self->{message_separator}, $self->{message} );
	}
	foreach ( qw(status message description response_xml response_json) ) {
		$self->{$_} = URI::Escape::uri_unescape( $self->{$_} );
	}
}

1;