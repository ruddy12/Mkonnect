// Load API Class
import UXTsms;

public class Example {
    public static void main(String[] args) {
    
        // Setup API credentials
        String apiKey = "Your API Key"; //Check under Manage Settings->Manage API in UXTsms 
       
        // API Call to Send Message(s)
        // Request        
        UXTsms uxtsms = new UXTsms(apiKey);  // Instantiate API library
        uxtsms.queue_sms("+254723XXXXXX", "Message 1", "Sender_ID", ""); // Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")
        uxtsms.queue_sms("+254733XXXXXX", "Message 2", "Sender_ID", ""); // Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")
        uxtsms.send_sms(); // Initiate API call to send messages

        // Response
        System.out.println(uxtsms.status); // View status either (SUCCESS or FAIL)
        System.out.println(uxtsms.message); // Returns SMS available (Credits balance) 
        System.out.println(uxtsms.description); // Returns a status message 
        System.out.println(uxtsms.response_xml); // Returns full xml response 
        System.out.println(uxtsms.response_json); // Returns full json response 

        // API Call to Check for Available SMS
        // Request        
        UXTsms uxtsms = new UXTsms(apiKey);  // Instantiate API library
        uxtsms.get_balance(); // Initiate API call to send messages

        // Response
        System.out.println(uxtsms.status); // View status either (SUCCESS or FAIL)
        System.out.println(uxtsms.message); // Returns SMS available (Credits balance) 
        System.out.println(uxtsms.description); // Returns a status message 
        System.out.println(uxtsms.response_xml); // Returns full xml response 
        System.out.println(uxtsms.response_json); // Returns full json response 
    }
}
