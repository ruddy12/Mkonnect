# tumasms.rb  
# define class Tumasms  
require "uri"
require "net/https"
require "net/http"
require "rubygems"
require "json"
require 'active_support/core_ext/hash'

class UXTsms  

	attr_reader :status, :message, :description, :response_xml,:response_json

	# api call
	@api_domain;
	@api_url;
	@api_parameters;

	# api parameters
	@api_key;
	@sms_messages;

	# response
	@status;
	@message; 
	@description; 
	@response_xml;  
	@response_json; 

	def initialize(api_key="")  
		# Instance variables  

		@api_domain = "";
		@api_url = "";
		@api_parameters = Hash.new; 

		@api_key = api_key;    
		@sms_messages = "";
		
		@status = ""; 
		@message = "";  
		@description = "";  
		@response_xml = ""; 
		@response_json = "";  
	end

	def queue_sms(recipient, message, sender = "", scheduled_date = "")  
		@sms_messages += "<sms>";
		@sms_messages += "<recipient>" + recipient + "</recipient>";
		@sms_messages += "<message>" + message + "</message>";
		@sms_messages += "<sender>" + sender + "</sender>";
		@sms_messages += "<scheduled_date>" + scheduled_date + "</scheduled_date>";
		@sms_messages += "</sms>";
	end  

	def send_sms  
		@api_url = "send_sms";  
		@api_parameters["messages"] = URI.encode("<request>" + @sms_messages + "</request>");
		execute();    
	end

	def get_balance  
		@api_url = "get_balance";	
		execute();		
	end

	def execute  
		@api_domain = "http://tumasms.co.ke";
		@api_url = "/ts/api/" + @api_url;
		@api_parameters["api_key"] = URI.encode(@api_key); 
		
		uri = URI(@api_domain)
		http = Net::HTTP.new(uri.host, uri.port)
		request = Net::HTTP::Post.new(@api_url)
		request.set_form_data(@api_parameters)
		results = http.request(request)
		  
		if results.code == "200"

			@response_xml = results.body.strip;
			
			
			@response_json = Hash.from_xml(@response_xml).to_json;

		  	# Parse JSON
		  	response = JSON.parse(@response_json)

			@status = response["response"]["status"]["type"];
			@message = response["response"]["content"]["messages"]["message"];
			@description = response["response"]["content"]["description"];			  

		else
		  puts "Problem occurred : " + results.code;
		end

	end

end