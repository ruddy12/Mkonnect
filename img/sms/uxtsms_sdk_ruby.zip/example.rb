# Load API Class
require_relative "uxtsms";	
	
# Setup API credentials
API_KEY = "YOUR API KEY"; # Check under Manage Settings.Manage API in UXTsms 

# API Call to Send Message(s)
# Request	
uxtsms = UXTsms.new(API_KEY); # Instantiate API library
uxtsms.queue_sms("+254723XXXXXX", "Message 1.", "Sender_ID", ""); # Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")
uxtsms.queue_sms("+254733XXXXXX", "Message 2.", "Sender_ID", ""); # Replace example with valid recipient, message, sender id and scheduled datetime if required in format ("YYYY-MM-DD HH:mm:ss")
uxtsms.send_sms(); # Initiate API call to send messages
## Response	
puts uxtsms.status + "\r\n"; # View status either (SUCCESS or FAIL)
puts uxtsms.message + "\r\n"; # Returns SMS available (Credits balance)
puts uxtsms.description + "\r\n"; # Returns a status message
puts uxtsms.response_xml + "\r\n"; # Returns full xml response
puts uxtsms.response_json + "\r\n"; # Returns full json response

## API Call to Check for Available SMS
## Request
uxtsms = UXTsms.new(API_KEY); # Instantiate API library
uxtsms.get_balance(); # Initiate API call to check available messages
## Response
puts uxtsms.status + "\r\n"; # View status either (SUCCESS or FAIL)
puts uxtsms.message + "\r\n"; # Returns SMS available (Credits balance)
puts uxtsms.description + "\r\n"; # Returns a status message
puts uxtsms.response_xml + "\r\n"; # Returns full xml response
puts uxtsms.response_json + "\r\n"; # Returns full json response